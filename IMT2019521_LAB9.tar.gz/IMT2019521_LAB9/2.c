/*Program to add,subtract,multiply the given two complex numbers*/
/*INPUT:Real and imaginary parts of two complex numbers*/
/*OUTPUT:Result after performing Arithmetic operations on complex numbers*/
#include<stdio.h>
int main()
{
    struct complex_number/*Creating a structure for complex number*/
    {
        float real_part;
        float imaginary_part;
    };
    struct complex_number c1,c2;
    scanf("%f %f",&c1.real_part,&c1.imaginary_part);/*Storing data in the structure*/
    scanf("%f %f",&c2.real_part,&c2.imaginary_part);
    printf("%.2f + %.2fi\n",c1.real_part+c2.real_part,c1.imaginary_part+c2.imaginary_part);/*Adding two complex numbers*/
    printf("%.2f + %.2fi\n",c1.real_part-c2.real_part,c1.imaginary_part-c2.imaginary_part);/*Subtracting two complex numbers*/
    printf("%.2f + %.2fi\n",(c1.real_part*c2.real_part)-(c1.imaginary_part*c2.imaginary_part),(c1.imaginary_part*c2.real_part+c1.real_part*c2.imaginary_part));/*Multiplying two complex numbers*/
    return 0;
}
    
