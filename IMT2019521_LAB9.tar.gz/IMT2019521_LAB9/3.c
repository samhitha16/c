/*Program to store the data of a student*/
/*INPUT:Number of students and Data of the students*/
/*OUTPUT:Data of the student(s)*/
#include<stdio.h>
int main()
{
    struct student_info/*Creating a structure for student_information*/
    {
        char name[50];
        char roll_number[50];
        int age;
        int marks;
    };
    int n,i,j;
    scanf("%d\n",&n);/*Number of students*/
    struct student_info s[n];/*Declaring a structure array*/
    for(i=0;i<n;i++)/*Taking input data*/
        scanf("%s %s %d %d",s[i].name,s[i].roll_number,&s[i].age,&s[i].marks);
    for(j=0;j<n;j++)/*Priting the output*/
        printf("%s\n%s\n%d\n%d\n",s[j].name,s[j].roll_number,s[j].age,s[j].marks);
    return 0;
}
