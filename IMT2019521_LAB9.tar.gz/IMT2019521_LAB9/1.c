/*Program to use argv and argc*/
/*INPUT:Two numbers and the operand*/
/*OUTPUT:The result after the arithemetic operation*/
#include<stdio.h>
#include<stdlib.h>
int main( int argc,char *argv[])
{
    int a,b,c,result;
    a=atoi(argv[2]);/*Scaning the first number*/
    b=atoi(argv[3]);/*Scaning the second number*/
    c=*argv[4];/*Scaning the operand*/
    switch(c)/*Cases for different operands*/
    {
        case '+':
             result=a+b;
             break;
        case '-':
             result=a-b;
             break;
        case 'x':
             result=a*b;
             break;
        case '/':
             result=a/b;
             break;
    }
    printf("%d",result);/*Output*/
    return 0;
}
