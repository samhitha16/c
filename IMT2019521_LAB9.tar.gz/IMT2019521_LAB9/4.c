/*Program to use LinkedLists and delete odd numbers in it*/
/*INPUT:Number of numbers and numbers*/
/*OUTPUT:Linked list with all numbers and linked list with only even numbers*/
#include<stdio.h>
#include<stdlib.h>
typedef struct node/*Creating a structure for LinlkedList*/
{
    int data;/*Value of the number*/
    struct node * next;/*Pointer to the next node*/
}node;

node * createLinkedList(int n);
void displayList(node * head);
void rem_odd(node** head);
int main()
{
    int n=0;
    node *HEAD = NULL;
    scanf("%d",&n);/*Number of numbers*/
    HEAD=createLinkedList(n);
    displayList(HEAD);
    printf("\n");
    rem_odd(&HEAD);
    displayList(HEAD);
    return 0;
} 

node * createLinkedList(int n)/*Function to make a linked list from the inputed values*/
{
    int i=0;
    node * head=NULL;/*Address of first node*/
    node * temp=NULL;
    node * p=NULL;
    for(i=0;i<n;i++)
    {
        temp=(node*)malloc(sizeof(node));/*Creating a individual node*/
        scanf("%d",&(temp->data));
        temp->next = NULL;
        if(head==NULL)/*If list is empty make temp as the first node*/
        {
            head=temp;
        }
        else/*Combining the existing linkedlist and individual node*/
        {
            p=head;
            while(p->next !=NULL)
                p=p->next;
            p->next = temp;
        }
    }
        return head;
}
void displayList(node* head)/*Function to display the linkedlist created*/
{
    node * p=head;
    while(p !=NULL)
    {
        printf("%d-->",p->data);
        p=p->next;
    }
    printf("NULL");
}
void rem_odd(node** head)/*Function to delete the odd integers in it*/
{
    node* curr = *head;
    node* l_even;
    while (curr != NULL && curr->data % 2 != 0)/*Finding the first even element*/
    {
        curr = curr->next;
    }
    *head = curr;/*head is first even number*/
    if (curr == NULL) 
    {
        return;/*only head in linkedlist*/
    }
    l_even = curr;
    curr = curr->next;
    while (curr != NULL)
    {
        if (curr->data % 2 == 0)
        {
            l_even->next = curr;
            l_even = curr;
        }
        curr = curr->next;
    }
    l_even->next = NULL;
}
