/*INPUT:Numbers to make an array and a number to search in given array using linear search*/
/*OUTPUT:The presence of the number and number of comparisions*/
#include<stdio.h>
int main()
{
   int array[10],i=0,a,count=0,flag=0, start_pos=0, end_pos=9, pos ;
   while(i<10)
      scanf("%d,",&array[i++]);/*Making an array with given inputs*/
   scanf("%d",&a);/*The number to be searched in the given array*/

   while (start_pos <= end_pos) 
   { 
      count = count + 1;
      pos = start_pos + (end_pos-start_pos)/2; 
  
    /* Check if a is present at mid */
      if (array[pos] == a)  
      {   
	 flag=1;
	 break;
      }  
     /* If a greater than mid, ignore left half*/   
      else if (array[pos] < a)  
         start_pos = pos + 1;  
  
    /* If a is smaller than mid, ignore right half*/  
       else 
          end_pos = pos - 1;  
    } 


    printf("%d ",flag);
    printf("%d",count); 
    return 0;
}		
