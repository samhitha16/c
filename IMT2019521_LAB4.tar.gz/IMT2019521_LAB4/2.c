/*INPUT:Numbers to make an array and a number to search in given array using linear search*/
/*OUTPUT:The presence of the number and number of comparisions*/
#include<stdio.h>
int main()
{
   int array[10],i=0,a,count=0,flag=0;
   while(i<10)
      scanf("%d,",&array[i++]);/*Making an array with given inputs*/
   scanf("%d",&a);/*The number to be searched in the given array*/
   for(i=0;i<10;i++)/*Linear search*/
{
    count++;/*count is the number of comparisions required*/
    if(array[i]==a)
	{flag=1; /*The number is present in the array*/ 
	break;
}
}
   printf("%d ",flag);
   printf("%d",count); 
return 0;
}		
