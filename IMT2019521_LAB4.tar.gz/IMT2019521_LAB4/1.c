/*INPUT:Numbers to make an array*/
/*OUTPUT:Print in the numbers in the reverse orderof input*/
#include<stdio.h>
int main()
{
   int array[10],i=0;
   while(i<10)/*Making an array with given numbers*/
      scanf("%d,",&array[i++]);
   for(i=9;i>=0;i--)/*Printing the numbers in the reverse order*/
	printf("%d ",array[i]);
   return 0;
}		
