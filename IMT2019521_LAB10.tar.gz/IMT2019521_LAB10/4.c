/*Program to copy contents of one file to the other*/
/*INPUT:nothing*/
/*OUTPUT:A file created with the combined contents of the existing two files*/
#include<stdio.h>
#include<stdlib.h>
void copy(FILE *a,FILE *b)/*Function to copy contents of file a to file b*/
	{
	char c;
	if(a!=NULL)
		{
		if(b!=NULL)
			{
			c=fgetc(a);
			while(c!=EOF)
				{
				fputc(c,b);
				c=fgetc(a);
				}
			}
		}
	fclose(a);
	fclose(b);
	}
int main()
	{
	copy(fopen("file1.txt","r"),fopen("file.txt","w"));/*calling the function to copy contents with files in read and write mode respectively*/
	copy(fopen("file2.txt","r"),fopen("file.txt","a"));/*read and append mode respectively*/
	return 0;
	}
