/*Program to add and multiply two polynomials*/
/*INPUT:The degree and the co-efficients of the two polynomials*/
/*OUTPUT:The degree and the co-effecients of the two polynomials obtained after adding and multiplying*/
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n1,n2;
    int i;
    scanf("%d",&n1);/*Degree of the first polynomial*/
    double a[n1+1],c[50];
    for(i=n1;i>-1;i--)
        scanf("%lf",&a[i]);/*Storing co-efficients of first polynomial into an array*/
    scanf("%d",&n2);/*Degree of the second polynomial*/
    double b[n2+1];
    for(i=n2;i>-1;i--)
        scanf("%lf",&b[i]);/*Storing co-efficients of second polynomial into an array*/
    if(n1>n2 ||n1==n2)
    {
         for(i=0;i<n2+1;i++)
              c[i]=a[i]+b[i];
         for(i=n2+1;i<n1+1;i++)
              c[i]=a[i];
         double f=i-1;
         printf("%f ",f);/*Degree of the polynomial obtained after adding two polynomials*/
         for(i=n1;i>-1;i--)
              printf("%f ",c[i]);/*Array containing the co-efficients of the polynomial obtained after adding two polynomials*/
    }
    else
    {
         for(i=0;i<n1+1;i++)
              c[i]=a[i]+b[i];
         for(i=n1+1;i<n2+1;i++)
              c[i]=b[i];
         double e=i-1;
         printf("%f ",e);
         for(i=n2;i>-1;i--)
              printf("%f ",c[i]);
     }
double prod[n1+n2+1];
  for(int i=0;i<n1+n2+1;i++)
    prod[i]=0;
  for(int l=0;l<n1+1;l++)
  {
    for(int j=0;j<n2+1;j++)
      prod[l+j]=prod[l+j]+a[l]*b[j];/*Calculating the product of two polynomials using for loops*/
   }
double x=n1+n2;
printf("\n%f ",x);
for(int k=n1+n2;k>-1;k--)
  printf("%f ",prod[k]);/*Array with the co-efficients of the polynomial obtained by multiplying two polynomials*/

     return 0;
}

