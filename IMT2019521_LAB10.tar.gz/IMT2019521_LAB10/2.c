/*Program to write a minprint function which works similar to printf function*/
/*Used argv and argc (not mentioned in the question not use)*/
/*INPUT:A character or an integer*/
/*OUTPUT:The character or integer which you inputed*/
#include<stdio.h>
#include<stdarg.h>
#include<string.h>
#include<stdbool.h>
void print_int(int num)/*Function to print integer without using printf*/
  {
  int a = num;
  if (num < 0)
    {
     putchar('-');
     num = -num;
    }
  if (num > 9) 
     print_int(num/10);
  putchar('0'+ (a%10));
  }
void minprint(char *type, ...)/*minprint function with variable length arguments*/
   {
   va_list ap;
   char *p, *str;
   int num;
   va_start(ap, type); 
   for (p = type; *p; p++) 
   {
      if (*p != '%') 
      {
         putchar(*p);
         continue;
      }
      switch (*++p) 
      {
         case 'd':/*If input value is integer*/
            num = va_arg(ap, int);
           //printf("%d", ival);
            print_int(num);
            break;
        case 's':/*If input value is string*/
            for (str = va_arg(ap, char *); *str; str++)
            putchar(*str);
            break;

      }
   }
   va_end(ap);
}

int main(int argc,char *argv[])/*Scanning the input using argv and argc*/
{
minprint("%s",argv[1]);/*Callig the minprint function*/
return 0;
}
