/*Program to save the time in two different files with a difference of five seconds*/
/*INPUT:Nothing*/
/*OUTPUT:time with a gap of five seconds*/
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
char * print(FILE *fp)/*Function to print the data present in a file*/
    {
    char c;
    if(fp!=NULL)
         {
         c=fgetc(fp);
         while(c!=EOF)
             {
             printf("%c",c);
             c=fgetc(fp);
             }
          }
     fclose(fp);
     }
int main()
    {
    system("date>file1.txt");/*storing the date in file1*/
    sleep(5);/*Waiting for 5 seconds*/
    system("date>file2.txt");/*storing the date in file2*/
    print(fopen("file1.txt","r"));
    print(fopen("file2.txt","r"));
    return 0;
    }
