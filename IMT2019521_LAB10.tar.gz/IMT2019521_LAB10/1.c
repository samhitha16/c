/*Program to find the number of numbers entered and their sum*/
/*INPUT:Numbers*/
/*OUTPUT:Number of numbers and their sum*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])/*Command line arguments*/
{
    int n=argc,sum=0;/*Initialising sum to zero*/
    int i;
    int a[n-1];
    for(i=0;i<n-1;i++)
        a[i]=atoi(argv[i+1]);/*Making an array of numbers*/
    printf("%d ",n-1);/*Number of numbers*/
    for(i=0;i<n-1;i++)
        sum=sum+a[i];/*loop to caluculate sum*/
    printf("%d",sum);
    return 0;
}
