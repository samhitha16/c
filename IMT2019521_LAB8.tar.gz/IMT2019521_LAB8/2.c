/*Finding whether the endstring of the first string is same as second string*/
/*INPUT:Two strings*/
/*OUTPUT:0 or the string*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int strend(char*,char*);
int main()
{
int n;
char *pointer1,*pointer2;
pointer1=(char*)malloc(sizeof(char)*255);/*Allocating dynamic memory*/
pointer2=(char*)malloc(sizeof(char)*255);
scanf("%s %s",pointer1,pointer2);
n=strend(pointer1,pointer2);
if(n==0)/*String at the end of first string is not same as the second string*/
printf("%d",0);
else/*String at the end of first string is same as the second string*/
printf("%s",pointer2);
return 0;
}
int strend(char *pointer1,char *pointer2)/*Function taking pointers as arguments*/ 
{
int i,n,j;
i=strlen(pointer1)-strlen(pointer2);
if(i>-1)
{
for(n=0;n<i;n++)
*pointer1++;
for(j=0;j<strlen(pointer2);j++)
{
if(*pointer1++!=*pointer2++)
  return 0;
}
}
}

