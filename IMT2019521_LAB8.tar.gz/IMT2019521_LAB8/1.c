/*Conversion of a decimal to a any base*/
/*INTPUT:Number and the base*/
/*OUTPUT:Base number*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char result(int num)/*Function to convert ascii to alphabets*/ 
{ 
    if (num >= 0 && num <= 9) 
        return (char)(num+'0'); 
    else
        return (char)(num - 10 + 'a'); 
}
char* reverse(char *str)/*Function to reverse the array*/
{
    char *s;
    s=(char*)malloc(sizeof(char)*255);
    int i=0,z=strlen(str);
    for(i=0;i<z;i++)
        s[i]=str[z-i-1];
    return s;
} 
char* itob(int number,char *s1,int base)/*Function to covert a number to any base*/
{
    int index = 0; 
    while(number>0)
    {
         s1[index++]=result(number%base);/*Storing the remainder in array*/
         number=number/base;/*storing the quotient*/
    }
    s1[index]='\0';
    return reverse(s1);/*Reversing the array by calling the function*/ 
}
int main()
{
    int number,base;
    char *s;
    s=(char*)malloc(sizeof(char)*255);/*Allocting the dynamic memory*/
    scanf("%d %d",&number,&base);/*Taking the input*/
    printf("%s",itob(number,s,base));/*Calling a function*/
    return 0;
}



