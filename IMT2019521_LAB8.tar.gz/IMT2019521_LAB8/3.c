/*Function to do arithmetic operations */
/*INPUT:Two numbers and symbol for the respective operation to be carried out */
/*OUTPUT:Result of the arithmetic operation */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
float add(double a, double b)/*Function to add numbers*/
{
return a+b;
}
float subtract(double a, double b)/*Function to subtarct numbers*/
{
return a-b;
}
float multiply(double a,double b)/*Function to multiply numbers*/
{
return a*b;
}
float divide(double a, double b)/*Function to divide numbers*/
{
return a/b;
}
int main()
{
double a,b;
int f;
char d;
float (*p[4])(double,double)={add,subtract,multiply,divide};/*Creating function pointers*/
scanf("%lf %lf %c",&a,&b,&d);/*Taking the input*/
if(d=='+')
f=0;
else if(d=='-')
f=1;
else if(d=='*')
f=2;
else if(d=='/')
f=3;
printf("%.4f",p[f](a,b));/*Calling the function*/
return 0;
}
