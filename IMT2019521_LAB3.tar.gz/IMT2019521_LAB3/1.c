/*Finding circles are intersecting or not*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
/*(x1,y1) and (x2,y2) are the centers of two circles respectively*/
/*r1,r2 are the radii of two circles respectively*/
int x1,x2,y1,y2,r1,r2;
scanf("%d" "%d" "%d" "%d" "%d" "%d",&x1,&y1,&x2,&y2,&r1,&r2);
/*d is the distance between the centers of two circles*/
float d=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
int a=r1+r2;
int b=r1-r2;
/*Intersecting circles*/
if(abs(b)<=d && d<=a)
	{
	printf("YES\n");
	}
/*radius cannot be negative*/
else if(r1<0 || r2<0)
	{
	printf("Invalid input\n");
	}
/*Non-Intersecting circles*/
else 
	{
	printf("NO\n");
	}
return 0;
}

