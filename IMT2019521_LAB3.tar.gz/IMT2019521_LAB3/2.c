/*Finding the number of distinct sub-strings of given length*/
/*INPUT:A string consisting of lower-case alphabets and an integer for th e length of the substring*/
/*OUTPUT:Number of distinct substrings of given length*/
/*REMARK:If the length of string is less than the given length of substring then output is zero*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char* substring(char *str,int start_pos,int lenght)/*Function for finding substrings of given length*/
{
char* substring = malloc(sizeof(char)*(lenght+1));
memcpy(substring, &str[start_pos], lenght);
substring[lenght] = '\0';
return substring;
}
int main()
{
int n,count=0, position, diff;/*n is length of substring required*/

char* pos;/**/
char str[100];/*String inputed by the user*/
scanf("%s" "%d",str,&n);

diff = strlen(str)-n;/*Difference between the length of string and length of the substring required*/ 

for(int i = 0; i <= diff ; i++ )
{
char* sub =  substring(str, i, n);
pos = strstr(str, sub);
position = pos - str;
if (i==position)
count = count + 1;
}

printf("%d\n", count);
return 0;
}



