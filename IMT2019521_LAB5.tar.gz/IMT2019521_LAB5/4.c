/*Quick_Sort*/
/*INPUT:Size of the array and numbers which are to be stored in the array*/
/*OUTPUT:Sorted array and the index of the last pivot element*/
#include<stdio.h>
int pivot_index;
int partition(long long int array[], int p, int r)/*Function for paritition*/
{
	int pivot=array[r];/*Choosing the last element as the pivot element*/
	int i=(p-1);
	for (int j=p;j<=(r-1);j++)
	{
		if(array[j]<pivot)/*Moving all the elements lesser than pivot to the left*/
		{
			i++;
			int t=array[i];
			array[i]=array[j];
			array[j]=t;
		}
	}/*Moving all the elements greater than pivot to right*/
	int x=array[i+1];
	array[i+1]=array[r];
	array[r]=x;
	return (i+1);
}
void quick_sort(long long int array[],int p,int r)/*Function for Quick Sort*/
{	
	if(p<r)
	{
		int q=partition(array,p,r);/*Calling partition function*/
		quick_sort(array,p,q-1);/*Calling quick_sort after partition*/
		quick_sort(array,q+1,r);
		pivot_index=q;/*Index of the last pivot element*/
	}
}
int main()
{
int i=0,a;
scanf("%d\n",&a);/*Input the size of array from the user*/
long long int array[a];
for(i=0;i<a;i++)/*Making an array with the input numbers*/
	scanf("%lld,",&array[i]);
quick_sort(array,0,a-1);/*Calling the quick_sort function*/
i=0;
for(i=0;i<a;i++)/*Printing the sorted array*/
	printf("%lld ",array[i]);
printf("\n%d",pivot_index);/*Index of the last pivot element*/
return 0;
}
