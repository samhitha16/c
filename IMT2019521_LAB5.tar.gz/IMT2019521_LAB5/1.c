/*Program for Bubble sort*/
/*INPUT:Numbers to store in an array and sort using Bubble sort algorithm*/
/*OUTPUT:Sorted array , Number of swaps , Number of comparisions*/
#include<stdio.h>
int compare=0;/*Global variables to find number of swaps and comparisions*/
int swap=0;
void bubble_sort(long long int array[], int n)/*Function for bubble sort algorithm*/
{
int i,j;
for(i=0;i<n-1;i++)
	for(j=0;j<n-i-1;j++)
		{
		compare++;/*Comparing the adjacent elements*/
		if(array[j]>array[j+1])
			{
				long long int temp;
				temp = array[j];
				array[j] = array[j+1];
				array[j+1] = temp;
				swap++;/*Swaping the elements if necessary*/
			}
		}
}
int main()
{
long long int array[20];
for ( int i=0;i<20;i++)/*Storing the input numbers to make an array*/
	scanf("%lld,",&array[i]);
bubble_sort(array,20);/*Calling the function bubble_sort*/
for ( int i=0;i<20;i++)/*Printing the sorted array*/
	printf("%lld ",array[i]);
printf("\n%d %d",swap,compare);/*Printing the number of swaps and comparisions done in the used function*/
return 0;
}
