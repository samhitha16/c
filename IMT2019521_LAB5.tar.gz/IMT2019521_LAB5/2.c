/*Selection Sort*/
/*INPUT:Numbers to make an array*/
/*OUTPUT:Sorted array , number of swaps and number of comparisions made*/
#include<stdio.h>
int compare=0;/*Declaring compare and swap variables*/
int swap=0;
void selection_sort(long long int array[],int n)/*Function for selection sort*/
{
	int i,j,min,a;
	for(i=0;i<n-1;i++)
		{		
		min=i;/*Choosing the first element as the minimum*/
		for(j=i+1;j<n;j++)
			{
			compare++;/*Comparing the elements*/
			if(array[j]<array[min])/*Finding an element less than the assumed minimum variable*/
				min=j;/*Updating it to minimum*/
			}
			/*if(array[i]<array[min])*/
			int temp=array[i];/*Swaping the minimum element*/
			array[i]=array[min];
			array[min]=temp;
			swap++;
		
		}
}
int main()
{
long long int array[20];
for (int i=0;i<20;i++)/*Storing the input numbers into an array*/
	scanf("%lld,",&array[i]);
selection_sort(array,20);/*Calling the function selection_sort*/
for (int i=0;i<20;i++)/*Printing the sorted array*/
	printf("%lld ",array[i]);
printf("\n%d %d",swap,compare);/*Total number of swaps and comparisions*/
return 0;
}
