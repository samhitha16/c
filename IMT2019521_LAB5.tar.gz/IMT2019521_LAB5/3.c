/* Merge Sort */
/*INPUT:The size of the array and the numbers to be placed in the array*/ 
/*OUTPUT:sorted array and the number of times the merge function is called*/
#include<stdlib.h> 
#include<stdio.h> 
int count = 0;

void merge(long long array[], int l, int m, int r) 
{ 
	int i, j, k; 
	int n1 = m - l + 1;/*Size of the first temporary array*/ 
	int n2 = r - m;/*Size of second temporary array*/ 
	long long array1[n1], array2[n2];/*Temporary arrays to store the divided array elements*/ 
	for (i = 0; i < n1; i++) /*Putting data into temporary arrays*/
		array1[i] = array[l + i]; 
	for (j = 0; j < n2; j++) 
		array2[j] = array[m + 1+ j]; 

	/* Merge the temporary arrays back */
	i = 0; /* Initial index of first temporary array */
	j = 0; /* Initial index of second temporary array*/ 
	k = l; /* Initial index of merged array*/ 
	while (i < n1 && j < n2) 
	{ 
		if (array1[i] <= array2[j]) /*Comparing the elements of the two temporary arrays*/
		{ 
			array[k] = array1[i]; 
			i++; 
		} 
		else
		{ 
			array[k] = array2[j]; 
			j++; 
		} 
		k++; 
	} 

	/* Copy the remaining elements of first temporary array, if there 
	are any */
	while (i < n1) 
	{ 
		array[k] = array1[i]; 
		i++; 
		k++; 
	} 

	/* Copy the remaining elements of second temporary array, if there 
	are any */
	
	while (j < n2) 
	{ 
		array[k] = array2[j]; 
		j++; 
		k++; 
	} 
} 
void mergeSort(long long array[], int l, int r) /*Function for merge sort*/
{ 
	if (l < r) 
	{ 
		int m = l+(r-l)/2;  
		mergeSort(array, l, m); 
		mergeSort(array, m+1, r); 
		merge(array, l, m, r);
		count++; 
	} 
} 

int main() 
{ 
	int i,a;/*Input the size of the array*/
	scanf("%d",&a);
	long long array[a]; 
	for (int i=0; i<a;i++)/*Making an array with given elements*/
		scanf("%lld,", &array[i]);
 	mergeSort(array, 0, a-1);/*Calling merge sort*/ 
 	for (i=0; i < a; i++) /*Printing the sorted array*/
		printf("%lld ", array[i]); 
	printf("\n%d",count);/*number of times merge has been called*/
	return 0; 
} 

