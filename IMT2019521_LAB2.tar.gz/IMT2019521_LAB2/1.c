#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int gcd(int c, int d) 
{ 
    if (c == 0) 
        return d; 
        return gcd(d%c, c); 
}
int main() 
{ 
int a,b;
scanf("%d %d",&a,&b);
if(a==0 && b==0)
	{
	printf("Invalid input");
	}
else
	{		
	printf("%d\n",gcd(abs(a),abs(b)));
	}
return 0;
} 
