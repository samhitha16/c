#include<stdio.h>
int main()
{
double a,b;
scanf("%lf",&a);
b=((9*a)/5)+32;
printf("%.2lf\n",b);
return 0;
}

