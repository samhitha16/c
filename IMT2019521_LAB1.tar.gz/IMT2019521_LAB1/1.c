#include<stdio.h>
int main()
{
const float pi = 3.14;
float radius,area;
scanf("%f",&radius);
if(radius>=0)
{
area=pi*radius*radius;
printf("%.2f\n",area);
}
else
{
printf("Invalid input\n");
}
return 0;
}

