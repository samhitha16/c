#include<stdio.h>
int main()
{
int a,b,mod;
scanf("%d %d",&a,&b);
if(a>0 && b>0)
{
   if(a>=b)
   {
      mod=a%b;
      printf("%d\n",mod);
   }
   else
   {
       mod=b%a;
       printf("%d\n",mod);
   }
}
else
{
       printf("Invalid input\n");
}
}
