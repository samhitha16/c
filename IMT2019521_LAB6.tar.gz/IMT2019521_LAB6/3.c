/*Own version of strcat*/
/*INPUT:Two strings*/
/*OUTPUT:String which combines the two inputed strings*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void combine(char *,char *);
int main()
{
char *str1,*str2;/*Declaring the pointers*/
str1=(char*)malloc(sizeof(char)*255);/*Allocating dynamic memory*/
str2=(char*)malloc(sizeof(char)*255);
scanf("%s",str1);
scanf("%s",str2);
combine(str1,str2);/*Calling the function*/
return 0;
}
void combine(char *str1,char *str2)/*Function to combine strings*/
{
int n,j,i;
char *str3;
n=strlen(str1)+strlen(str2);/*Length of combined string*/
str3=(char*)malloc(sizeof(char)*n);/*Allocating dynamic memory*/
str3=str1;/*Copying str1 to str3*/
j=0,i=strlen(str1);
while(str2[j]!='\0')
{
str3[i]=str2[j];/*Copying str2 to str3*/
j++;
i++;
}
str3[i]='\0';
printf("%s",str3);/*Output string*/
}
