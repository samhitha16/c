/*Own version of strcmp function*/
/*INPUT:Two strings*/
/*OUTPUT:0 if strings are same ,1 if strings are different*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void compare(char*,char*);
int main()
{
char *str1,*str2;/*Declaring the pointers*/
str1=(char*)malloc(sizeof(char)*255);/*Allocating dynamic memory for two strings*/
str2=(char*)malloc(sizeof(char)*255);
scanf("%s",str1);/*Taking input of the two strings*/
scanf("%s",str2);
compare(str1,str2);
return 0;
}
void compare(char *str1, char *str2)/*Function to compare strings*/
{
int i,count;
if(strlen(str1)==strlen(str2))
{
for(i=0;i<strlen(str1);i++)
{
if(str1[i]==str2[i])
{
count=0;/*Strings are same*/
}
else
{
count=1;/*Strings are not same*/
}
}
}
else
{
count=1;/*Strings are not same*/
}
printf("%d",count);
}
 
