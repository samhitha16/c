/*INPUT:Number of integers to read and the integers*/
/*OUTPUT:Print the numbers that are given as input using a loop*/
#include<stdio.h>
#include<stdlib.h>
int main()
{
int n;/*Number of integers*/
int *p;/*Declaring a pointer*/
int i;
scanf("%d",&n);
p=(int*)malloc(n*sizeof(int));/*Allocating dynamic memory to store the integers*/
for(i=0;i<n;i++)
scanf("%d",&p[i]);
for(i=0;i<n;i++)/*Printing the integers using a loop*/
printf("%d ",p[i]);
free(p);/*free the allocated space*/
return 0;
}
